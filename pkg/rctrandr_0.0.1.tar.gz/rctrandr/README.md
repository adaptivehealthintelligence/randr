# rctrandr

  <!-- badges: start -->
  [![R-CMD-check](https://github.com/jatotterdell/rctrandr/workflows/R-CMD-check/badge.svg)](https://github.com/jatotterdell/rctrandr/actions)
  <!-- badges: end -->
